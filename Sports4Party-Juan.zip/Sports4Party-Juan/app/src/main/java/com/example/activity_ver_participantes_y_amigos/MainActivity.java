package com.example.activity_ver_participantes_y_amigos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button accionParticipantes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accionParticipantes = findViewById(R.id.botonparticipantes);

        getSupportActionBar().setTitle("Información del evento");

        accionParticipantes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent verParticipantes = new Intent(v.getContext(), Participantes.class);
                startActivity(verParticipantes);
            }
        });
    }
}
