package com.example.activity_ver_participantes_y_amigos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class Participantes extends AppCompatActivity {

    Button agregarAmigos;
    ListView listaAsistentes;
    String[] party = new String[4];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participantes);

        agregarAmigos = findViewById(R.id.botonanadiramigos);
        listaAsistentes = findViewById(R.id.listaparticipantes);

        getSupportActionBar().setTitle("Participantes del evento");

        party[0] = "Juan Hamon \n Nivel de habilidad: Bueno \n Amigos: 40";
        party[1] = "Santiago Chaparro \n Nivel de habilidad: Malo \n Amigos: 10";
        party[2] = "Diego Barajas \n Nivel de habilidad: Regular \n Amigos: 25";
        party[3] = "Brandonn Cruz \n Nivel de habilidad: Bueno \n Amigos: 39";

        ArrayAdapter<String> adapter=  new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, party);
        listaAsistentes.setAdapter(adapter);

        agregarAmigos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent AA = new Intent(v.getContext(),AgregarAmigos.class);
                startActivity(AA);
            }
        });
    }
}
