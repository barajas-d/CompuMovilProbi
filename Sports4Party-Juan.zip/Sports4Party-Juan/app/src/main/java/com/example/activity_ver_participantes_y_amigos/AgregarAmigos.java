package com.example.activity_ver_participantes_y_amigos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class AgregarAmigos extends AppCompatActivity {

    ListView amigos;
    String[] friends = new String[4];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_amigos);

        getSupportActionBar().setTitle("Agregar amigos");
        amigos = findViewById(R.id.listaamigos);

        friends[0] = "Pedro Fernandez \n Nivel de habilidad: Bueno";
        friends[1] = "Santiago Herrera \n Nivel de habilidad: Malo";
        friends[2] = "Carlos Orduz \n Nivel de habilidad: Regular";
        friends[3] = "Diego Martinez \n Nivel de habilidad: Bueno";

        ArrayAdapter<String> adapter=  new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, friends);
        amigos.setAdapter(adapter);
    }
}
